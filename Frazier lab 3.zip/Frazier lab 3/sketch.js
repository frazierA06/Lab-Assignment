let where = 0;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  let x = frameCount % 400;

  // If the mouse is pressed,
  // decrease the frame rate.
  if (mouseIsPressed === true) {
   frameRate(60);
  } else {
    frameRate(60);
  }

  circle(- x + 400 , 200, 40);
  circle(x , 200, 40);
  
  if(mouseY > 220 || mouseY < 150) {   
  } else if (mouseX < 20 || mouseX < (-x + 400)  === true,frameRate(5))  {
  
    
  }

    line(400, mouseY, mouseX, mouseY);
      line(-200, mouseY, mouseX, mouseY);

  
      line(400, mouseY+30, mouseX, mouseY+30);
        line(-200, mouseY+30, mouseX, mouseY+30);

  
  line(50, 0, 50, 100);

  // Calculate the mouse's distance from the middle.
 let b = abs(mouseX - 200);

  // Draw a rectangle based on the mouse's distance
  // from the middle.
  rect(0, 400 - b, 400, - b);



}