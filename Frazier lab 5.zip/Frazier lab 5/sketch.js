let a = [];
let b = [];
let c = []; 
let d = [];


function setup() {
  createCanvas(400, 400);
  
  c = color(0, 0, 255);
   a = color(255, 0, 0);
   b = color(0, 255, 0);
   d = color(255, 255, 0);


}

function draw() {
  background(220);
  
 

  //let a = [];
//  a[0]=255;
//  a[1]=0;
//  a[2]=0;

  
//  let b = [];
//  b[0]=0;
//  b[1]=255;
//  b[2]=0;
  
  //fill(b[0],b[1],b[2]);
  
  


  
   rect(160, 300, 80, 80);

let mx = mouseX ;
let my = mouseY ;
  
 let g = ellipse(50, 325, 80, 80);
  
  let p = ellipse(350, 325, 80, 80);



}

function mousePressed() {

  
  if ((mouseX > 15) && (mouseX < 85) && (mouseY < 380) && (mouseY > 280)){
   fill(d);
  
  }
  else {
    fill(a);
  }
  
  
}


function keyPressed() {
  if ((mouseX > 300) && (mouseX < 390) && (mouseY < 360) && (mouseY > 280)){
     fill(c);
  
    }
    else {
    fill(a);
  }
  

} 

function mouseClicked() {
  if ((mouseX > 160) && (mouseX < 240) && (mouseY < 380) && (mouseY > 280)){
   fill(b);
  
  }
  else {
    fill(a);
    
  }
  
}
